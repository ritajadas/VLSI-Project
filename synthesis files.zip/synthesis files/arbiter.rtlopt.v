/////////////////////////////////////////////////////////////
// Created by: Synopsys Design Compiler(R)
// Version   : M-2016.12-SP3
// Date      : Mon May  2 19:50:23 2022
/////////////////////////////////////////////////////////////


module arbiter ( r, Resetn, Clock, g );
  input [3:1] r;
  output [3:1] g;
  input Resetn, Clock;
  wire   N0, N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15,
         N16, N17, N18, N19, N20, N21, N22, N23, N24, N25, N26, N27, N28, N29,
         N30, N31, N32, N33, N34, N35, N36, N37;
  wire   [2:1] y;
  wire   [2:1] Y;
  assign g[3] = N32;
  assign g[2] = N35;
  assign g[1] = N36;

  GTECH_AND2 C6 ( .A(N33), .B(N30), .Z(N10) );
  GTECH_OR2 C8 ( .A(y[2]), .B(N30), .Z(N11) );
  GTECH_OR2 C11 ( .A(N33), .B(y[1]), .Z(N13) );
  GTECH_AND2 C13 ( .A(y[2]), .B(y[1]), .Z(N15) );
  GTECH_AND2 C22 ( .A(N16), .B(N17), .Z(N19) );
  GTECH_AND2 C23 ( .A(N19), .B(N18), .Z(N20) );
  GTECH_OR2 C25 ( .A(r[3]), .B(N17), .Z(N21) );
  GTECH_OR2 C28 ( .A(r[3]), .B(r[2]), .Z(N23) );
  GTECH_OR2 C29 ( .A(N23), .B(N18), .Z(N24) );
  \**SEQGEN**  \y_reg[2]  ( .clear(1'b0), .preset(1'b0), .next_state(N29), 
        .clocked_on(Clock), .data_in(1'b0), .enable(1'b0), .Q(y[2]), 
        .synch_clear(1'b0), .synch_preset(1'b0), .synch_toggle(1'b0), 
        .synch_enable(1'b1) );
  \**SEQGEN**  \y_reg[1]  ( .clear(1'b0), .preset(1'b0), .next_state(N28), 
        .clocked_on(Clock), .data_in(1'b0), .enable(1'b0), .Q(y[1]), 
        .synch_clear(1'b0), .synch_preset(1'b0), .synch_toggle(1'b0), 
        .synch_enable(1'b1) );
  GTECH_NOT I_0 ( .A(y[1]), .Z(N30) );
  GTECH_OR2 C74 ( .A(N30), .B(y[2]), .Z(N31) );
  GTECH_NOT I_1 ( .A(N31), .Z(N32) );
  GTECH_NOT I_2 ( .A(y[2]), .Z(N33) );
  GTECH_OR2 C77 ( .A(y[1]), .B(N33), .Z(N34) );
  GTECH_NOT I_3 ( .A(N34), .Z(N35) );
  GTECH_AND2 C79 ( .A(y[1]), .B(y[2]), .Z(N36) );
  GTECH_NOT I_4 ( .A(Resetn), .Z(N37) );
  SELECT_OP C81 ( .DATA1({1'b0, 1'b0}), .DATA2({1'b0, 1'b1}), .DATA3({1'b1, 
        1'b0}), .DATA4({1'b1, 1'b1}), .CONTROL1(N0), .CONTROL2(N1), .CONTROL3(
        N2), .CONTROL4(N3), .Z({N27, N26}) );
  GTECH_BUF B_0 ( .A(N20), .Z(N0) );
  GTECH_BUF B_1 ( .A(r[3]), .Z(N1) );
  GTECH_BUF B_2 ( .A(N22), .Z(N2) );
  GTECH_BUF B_3 ( .A(N25), .Z(N3) );
  SELECT_OP C82 ( .DATA1({N27, N26}), .DATA2({1'b0, r[3]}), .DATA3({r[2], 1'b0}), .DATA4({r[1], r[1]}), .CONTROL1(N4), .CONTROL2(N5), .CONTROL3(N6), 
        .CONTROL4(N7), .Z(Y) );
  GTECH_BUF B_4 ( .A(N10), .Z(N4) );
  GTECH_BUF B_5 ( .A(N12), .Z(N5) );
  GTECH_BUF B_6 ( .A(N14), .Z(N6) );
  GTECH_BUF B_7 ( .A(N15), .Z(N7) );
  SELECT_OP C83 ( .DATA1({1'b0, 1'b0}), .DATA2(Y), .CONTROL1(N8), .CONTROL2(N9), .Z({N29, N28}) );
  GTECH_BUF B_8 ( .A(N37), .Z(N8) );
  GTECH_BUF B_9 ( .A(Resetn), .Z(N9) );
  GTECH_NOT I_5 ( .A(N11), .Z(N12) );
  GTECH_NOT I_6 ( .A(N13), .Z(N14) );
  GTECH_NOT I_7 ( .A(r[3]), .Z(N16) );
  GTECH_NOT I_8 ( .A(r[2]), .Z(N17) );
  GTECH_NOT I_9 ( .A(r[1]), .Z(N18) );
  GTECH_NOT I_10 ( .A(N21), .Z(N22) );
  GTECH_NOT I_11 ( .A(N24), .Z(N25) );
endmodule

