### Tcl test bench for the pipelined multipler
###
### See /uusoc/facility/cad_tools/Synopsys/sold/sold for modelsim interface
### http://www.tcl.tk/man/tcl8.5/tutorial/tcltutorial.html for tcl tutorial
###
### kss, 10/31/2005
set Default radix=unsigned
view wave

add wave -radix unsigned r g
add wave Clock Resetn
add wave -divider "Internal nodes"
##add wave y Y


# define clock
set clk_period 20
## define clock to q for earliest input time
## I gave the design a 100ps delay for inputs and sampling output
set clk_offset 100
## define the setup time (when data is sampled)
## I used 50ps in the synthesis script.
set TSETUP 50




# initialize network, reset sytem
force r 0
force Clock 0 0,1 [expr 0.5* $clk_period] ns -repeat $clk_period ns
force Resetn 0
run [expr 2 * $clk_period]
force Resetn 1 15

echo starting simulation...

echo starting VCD dump at $now
vcd file arbiter1.vcd
vcd add -r /*
vcd on


force r 10#7 25 ns
force r 10#0 45 ns
force r 10#2 65 ns
force r 10#4 85 ns
force r 10#1 105 ns
force r 10#0 125 ns
force r 10#5 145 ns
force r 10#0 165 ns
force r 10#3 185 ns

##force r  'b0111 25 ns
##force r  'b0000 45 ns
##force r  'b0010 65 ns
##force r  'b0100 85 ns
##force r  'b0001 105 ns
##force r  'b0000 125 ns
##force r  'b0101 145 ns
##force r  'b0000 165 ns
##force r  'b0011 185 ns

run 500ns

echo ... simulation done!
echo finishing VCD dump at $now
vcd off
vcd flush



quit
