`timescale 1ns / 1ps
module test_arbiter;
	reg [3:1] r;
	reg Resetn;
	reg Clock;
	wire [3:1] g;
	reg[2:1] y,Y;
	
	arbiter a1(r,Resetn,Clock,g);
	initial begin
		Clock =1'b0;
		Resetn =1'b0;
		#15
		Resetn=1'b1;
		#10
		r=3'b111;
		#20
		r=3'b000;
		#20
		r=3'b010;
		#20
		r=3'b100;
		#20
		r=3'b001;
		#20
		r=3'b000;
		#20
		r=3'b101;
		#20
		r=3'b000;
		#20
		r=3'b011;
		

	end
	always #10 Clock = ~Clock;
endmodule
